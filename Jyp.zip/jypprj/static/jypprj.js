function prev(){
	$(".first").css("display","block");
}

function next(){
	$(".first").css("display","none");
}



