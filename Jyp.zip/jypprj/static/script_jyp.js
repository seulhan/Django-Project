
$(document).ready(
	function() {
		
	}
);


//메인페이지
function main_click_list1() {
   document.getElementById('mainlist1').className = 'mbtn_select';
   document.getElementById('mainlist2').className = 'mbtn';
   document.getElementById('mainlist3').className = 'mbtn';
   document.getElementById('mainlist4').className = 'mbtn';
   $(".ballad").css("display","block");
   $(".dance").css("display","none");
   $(".rap").css("display","none");
   $(".rnb").css("display","none");
}

function main_click_list2() {
   document.getElementById('mainlist1').className = 'mbtn';
   document.getElementById('mainlist2').className = 'mbtn_select';
   document.getElementById('mainlist3').className = 'mbtn';
   document.getElementById('mainlist4').className = 'mbtn';
   $(".ballad").css("display","none");
   $(".dance").css("display","block");
   $(".rap").css("display","none");
   $(".rnb").css("display","none");
}

function main_click_list3() {
   document.getElementById('mainlist1').className = 'mbtn';
   document.getElementById('mainlist2').className = 'mbtn';
   document.getElementById('mainlist3').className = 'mbtn_select';
   document.getElementById('mainlist4').className = 'mbtn';
   $(".ballad").css("display","none");
   $(".dance").css("display","none");
   $(".rap").css("display","block");
   $(".rnb").css("display","none");
}

function main_click_list4() {
   document.getElementById('mainlist1').className = 'mbtn';
   document.getElementById('mainlist2').className = 'mbtn';
   document.getElementById('mainlist3').className = 'mbtn';
   document.getElementById('mainlist4').className = 'mbtn_select';
   $(".ballad").css("display","none");
   $(".dance").css("display","none");
   $(".rap").css("display","none");
   $(".rnb").css("display","block");
}

// 추천페이지
function genre_click_list1() {
   document.getElementById('genrelist1').className = 'mbtn_select';
   document.getElementById('genrelist2').className = 'mbtn';
   document.getElementById('genrelist3').className = 'mbtn';
   document.getElementById('genrelist4').className = 'mbtn';
   $(".ballad").css("display","block");
   $(".dance").css("display","none");
   $(".rap").css("display","none");
   $(".rnb").css("display","none");
}

function genre_click_list2() {
   document.getElementById('genrelist1').className = 'mbtn';
   document.getElementById('genrelist2').className = 'mbtn_select';
   document.getElementById('genrelist3').className = 'mbtn';
   document.getElementById('genrelist4').className = 'mbtn';
   $(".ballad").css("display","none");
   $(".dance").css("display","block");
   $(".rap").css("display","none");
   $(".rnb").css("display","none");
}

function genre_click_list3() {
   document.getElementById('genrelist1').className = 'mbtn';
   document.getElementById('genrelist2').className = 'mbtn';
   document.getElementById('genrelist3').className = 'mbtn_select';
   document.getElementById('genrelist4').className = 'mbtn';
   $(".ballad").css("display","none");
   $(".dance").css("display","none");
   $(".rap").css("display","block");
   $(".rnb").css("display","none");
}

function genre_click_list4() {
   document.getElementById('genrelist1').className = 'mbtn';
   document.getElementById('genrelist2').className = 'mbtn';
   document.getElementById('genrelist3').className = 'mbtn';
   document.getElementById('genrelist4').className = 'mbtn_select';
   $(".ballad").css("display","none");
   $(".dance").css("display","none");
   $(".rap").css("display","none");
   $(".rnb").css("display","block");
}


// 전체음악 페이지
function chart_click_list1() {
	document.getElementById('chartlist1').className = 'btn_select';
	document.getElementById('chartlist2').className = 'btn';
	document.getElementById('chartlist3').className = 'btn';
	document.getElementById('chartlist4').className = 'btn';
	document.getElementById('chartlist5').className = 'btn';
	document.getElementById('chartlist6').className = 'btn';
	document.getElementById('chartlist7').className = 'btn';
	document.getElementById('chartlist8').className = 'btn';
	document.getElementById('chartlist9').className = 'btn';
}

function chart_click_list2() {
	document.getElementById('chartlist1').className = 'btn';
	document.getElementById('chartlist2').className = 'btn_select';
	document.getElementById('chartlist3').className = 'btn';
	document.getElementById('chartlist4').className = 'btn';
	document.getElementById('chartlist5').className = 'btn';
	document.getElementById('chartlist6').className = 'btn';
	document.getElementById('chartlist7').className = 'btn';
	document.getElementById('chartlist8').className = 'btn';
	document.getElementById('chartlist9').className = 'btn';
}

function chart_click_list3() {
	document.getElementById('chartlist1').className = 'btn';
	document.getElementById('chartlist2').className = 'btn';
	document.getElementById('chartlist3').className = 'btn_select';
	document.getElementById('chartlist4').className = 'btn';
	document.getElementById('chartlist5').className = 'btn';
	document.getElementById('chartlist6').className = 'btn';
	document.getElementById('chartlist7').className = 'btn';
	document.getElementById('chartlist8').className = 'btn';
	document.getElementById('chartlist9').className = 'btn';
}

function chart_click_list4() {
	document.getElementById('chartlist1').className = 'btn';
	document.getElementById('chartlist2').className = 'btn';
	document.getElementById('chartlist3').className = 'btn';
	document.getElementById('chartlist4').className = 'btn_select';
	document.getElementById('chartlist5').className = 'btn';
	document.getElementById('chartlist6').className = 'btn';
	document.getElementById('chartlist7').className = 'btn';
	document.getElementById('chartlist8').className = 'btn';
	document.getElementById('chartlist9').className = 'btn';
}

function chart_click_list5() {
	document.getElementById('chartlist1').className = 'btn';
	document.getElementById('chartlist2').className = 'btn';
	document.getElementById('chartlist3').className = 'btn';
	document.getElementById('chartlist4').className = 'btn';
	document.getElementById('chartlist5').className = 'btn_select';
	document.getElementById('chartlist6').className = 'btn';
	document.getElementById('chartlist7').className = 'btn';
	document.getElementById('chartlist8').className = 'btn';
	document.getElementById('chartlist9').className = 'btn';
}

function chart_click_list6() {
	document.getElementById('chartlist1').className = 'btn';
	document.getElementById('chartlist2').className = 'btn';
	document.getElementById('chartlist3').className = 'btn';
	document.getElementById('chartlist4').className = 'btn';
	document.getElementById('chartlist5').className = 'btn';
	document.getElementById('chartlist6').className = 'btn_select';
	document.getElementById('chartlist7').className = 'btn';
	document.getElementById('chartlist8').className = 'btn';
	document.getElementById('chartlist9').className = 'btn';
}

function chart_click_list7() {
	document.getElementById('chartlist1').className = 'btn';
	document.getElementById('chartlist2').className = 'btn';
	document.getElementById('chartlist3').className = 'btn';
	document.getElementById('chartlist4').className = 'btn';
	document.getElementById('chartlist5').className = 'btn';
	document.getElementById('chartlist6').className = 'btn';
	document.getElementById('chartlist7').className = 'btn_select';
	document.getElementById('chartlist8').className = 'btn';
	document.getElementById('chartlist9').className = 'btn';
}

function chart_click_list8() {
	document.getElementById('chartlist1').className = 'btn';
	document.getElementById('chartlist2').className = 'btn';
	document.getElementById('chartlist3').className = 'btn';
	document.getElementById('chartlist4').className = 'btn';
	document.getElementById('chartlist5').className = 'btn';
	document.getElementById('chartlist6').className = 'btn';
	document.getElementById('chartlist7').className = 'btn';
	document.getElementById('chartlist8').className = 'btn_select';
	document.getElementById('chartlist9').className = 'btn';
}

function chart_click_list9() {
	document.getElementById('chartlist1').className = 'btn';
	document.getElementById('chartlist2').className = 'btn';
	document.getElementById('chartlist3').className = 'btn';
	document.getElementById('chartlist4').className = 'btn';
	document.getElementById('chartlist5').className = 'btn';
	document.getElementById('chartlist6').className = 'btn';
	document.getElementById('chartlist7').className = 'btn';
	document.getElementById('chartlist8').className = 'btn';
	document.getElementById('chartlist9').className = 'btn_select';
}

function storage_click_like() {
	document.getElementById('likelist').className = 's_btn_select';
	document.getElementById('commentlist').className = 's_btn';
	document.getElementById('playlist').className = 's_btn';
}

function storage_click_comment() {
	document.getElementById('likelist').className = 's_btn';
	document.getElementById('commentlist').className = 's_btn_select';
	document.getElementById('playlist').className = 's_btn';
}

function storage_click_playlist() {
	document.getElementById('likelist').className = 's_btn';
	document.getElementById('commentlist').className = 's_btn';
	document.getElementById('playlist').className = 's_btn_select';
}



// 아이디 중복 확인 및 정규표현식

//id 중복확인 Ajax
$(document).ready(
	function () {
		$("#id_result").html("&nbsp;아이디를 입력하세요" );
	}
);

function idverify(){
	$.ajax({
			url : "idconfirm",
			type : "POST",
			data : {
				"id" : $("input[name=id]").val()
			},
			dataType : "text",
			success : function (data) {
				if (data =="중복되는 아이디 입니다."){
					registerform.id_check.value=0				
				} else if (data =="사용가능한 아이디입니다."){
					registerform.id_check.value=1	
				} else if(data=="영어와 숫자만 입력해주세요."){
					registerform.id_check.value=0
				}
				
				$("#id_result").html(data);
			},
			error : function () {}
		}
	);
}

$(document).ready(
	function () {
		$("#nick_result").html("&nbsp;닉네임을 입력하세요" );
	}
);

function nickverify(){
	$.ajax({
			url : "nameconfirm",
			type : "POST",
			data : {
				"nickname" : $("input[name=name]").val()
			},
			dataType : "text",
			success : function (data) {
				if (data =="중복되는 닉네임 입니다."){
					registerform.n_check.value=0				
				} else if (data =="사용가능한 닉네임입니다."){
					registerform.n_check.value=1	
				}
			
				$("#nick_result").html(data);
			},
			error : function () {}
		}
	);
}

var eng = /^[a-zA-Z]*$/; 
function idconfirm() {
	
	if( ! $("input[name=id]").val() ) {
		alert( "아이디를 입력하세요" );
		$("input[name=id]").focus();
		return false; 		
	} else if(  ! eng.test( $( "input[name=id]" ).val() ) ){
			alert("아이디는 영어만 사용해주세요.");
			$("input[name=id]").focus();
			return false;
	}else {
		url = "idconfirm" + "?id=" + $("input[name=id]").val();
		open( url, "confirm", 
		"toolbar=no, menubar=no, scrollbar=no, status=no, width=400, height=250" );
	}
}
function set_id( id ) {
	opener.document.registerform.id.value = id;
	opener.document.registerform.id_check.value = 1;
	self.close();
}
function init_id(){
	document.registerform.id_check.value = 0;
}


// 닉네임 중복 확인 - 회원가입
function nameconfirm() {
	if( ! $("input[name=name]").val() ) {
		alert( "닉네임을 입력하세요" );
		$("input[name=name]").focus();
		return false; 		
	} else {
		url = "nameconfirm" + "?name=" + $("input[name=name]").val();
		open( url, "confirm", 
		"toolbar=no, menubar=no, scrollbar=no, status=no, width=400, height=250" );
	}
}

function set_name( name ) {
	opener.document.registerform.name.value = name;
	opener.document.registerform.n_check.value = 1;
	self.close();
}

function init_name(){
	document.registerform.n_check.value = 0;
}

// 회원가입 체크 사항
function registercheck() {
	if( $("input[name=passwd]").val() != $("input[name=passwd1]").val() ) {
		alert( "비밀번호가 다릅니다." );
		$("input[name=passwd]").focus();
		return false;
	} else if ($("input[name=birthday]").val().length < 6) {
         alert("생년월일은 6자로 입력하세요.");
         $("input[name=birthday]").focus();
         return false;
 	}else if(isNaN($("input[name=birthday]").val())){
 		alert("생년월일은 숫자만 입력해주세요.");
 		$("input[name=birthday]").focus();
 		return false;
 	}else if( $("input[name=id_check]").val() == 0 ){
 		alert("아이디 중복확인을 해주세요.");
 		$("input[name=id]").focus();
 		return false;
 	}else if( $("input[name=n_check]").val() == 0 ){
 		alert("닉네임 중복확인을 해주세요.");
 		$("input[name=name]").focus();
 		return false;
 	}
}

// 로그인
function logincheck() {
	if( ! $("input[name=id]").val() ) {
		alert( "아이디를 입력하세요." );
		$("input[name=id]").focus();
		return false;
	} else if( ! $("input[name=passwd]").val() ) {
		alert( "비밀번호를 입력하세요." );
		$("input[name=passwd]").focus();
		return false;
	}
}

// 비밀번호 찾기
function pw_recover() {
	if( ! $("input[name=id]").val() ) {
		alert( "id를 입력하세요." );
		$("input[name=id]").focus();
		return 		
	} else if( ! $("input[name=birthday]").val() ) {
      alert( "생년월일을 입력하세요." );
      $("input[name=birthday]").focus();
      return false;
   } else {
		url = "pw_recover" + "?id=" + $("input[name=id]").val() + "&birthday=" + $("input[name=birthday]").val();
		open( url, "pw_recover", 
		"toolbar=no, menubar=no, scrollbar=no, status=no, width=400, height=250" );
	}
}

// 비번찾고 로그인하러 가기
function relogin( id ) {
	self.close()
	url = "loginpage" + "?id=" + $("input[name=id]").val();
	open( url, "loginpage" )
}

// 탈퇴페이지
function deleteprock() {
	if( ! $("input[name=passwd]").val() ) {
		alert( "비밀번호를 입력하세요." );
		$("input[name=passwd]").focus();
		return false;
	}
}




// 닉네임 중복 확인 - 정보수정
function nameconfirm1() {
	if( ! $("input[name=name]").val() ) {
		alert( "닉네임을 입력하세요" );
		$("input[name=name]").focus();
		return; 		
	} else {
		url = "nameconfirm1" + "?name=" + $("input[name=name]").val();
		open( url, "confirm", 
		"toolbar=no, menubar=no, scrollbar=no, status=no, width=400, height=250" );
	}
}

function setname1( name ) {
	opener.document.modifyform.name.value = name
	self.close();
}

function likebtn() {
	alert( "내 좋아요 리스트에 추가되었습니다." );
	return false;
}

function likebtn2() {
	alert( "내 좋아요 리스트에서 삭제되었습니다." );
	return false;
}

function playlistbtn() {
	alert( "내 플레이리스트에 추가되었습니다." );
	return false;
}

function playlistbtn2() {
	alert( "내 플레이리스트에서 삭제되었습니다." );
	return false;
}












